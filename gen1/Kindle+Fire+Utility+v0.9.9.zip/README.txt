oooo    oooo  o8o                    .o8  oooo               oooooooooooo  o8o                     
`888   .8P'   `"'                   "888  `888               `888'     `8  `"'                     
 888  d8'    oooo  ooo. .oo.    .oooo888   888   .ooooo.      888         oooo  oooo d8b  .ooooo.  
 88888[      `888  `888P"Y88b  d88' `888   888  d88' `88b     888oooo8    `888  `888""8P d88' `88b 
 888`88b.     888   888   888  888   888   888  888ooo888     888    "     888   888     888ooo888 
 888  `88b.   888   888   888  888   888   888  888    .o     888          888   888     888    .o 
o888o  o888o o888o o888o o888o `Y8bod88P" o888o `Y8bod8P'    o888o        o888o d888b    `Y8bod8P' 
                                                                                                   
                                                                                                   
                                                                                                   
                    ooooo     ooo     .    o8o  oooo   o8o      .               
                    `888'     `8'   .o8    `"'  `888   `"'    .o8               
                     888       8  .o888oo oooo   888  oooo  .o888oo oooo    ooo 
                     888       8    888   `888   888  `888    888    `88.  .8'  
                     888       8    888    888   888   888    888     `88..8'   
                     `88.    .8'    888 .  888   888   888    888 .    `888'    
                       `YbodP'      "888" o888o o888o o888o   "888"     .8'     
                                                                    .o..P'      
                                                                    `Y8P'       

Basic use should be pretty straight forward.

Advanced Feature information:

1. Dual Boot
	The dual boot feature installs a modified bootloader that enables you to repartition your 
	device and install Alt-Roms. The process is simple: Install FFFe > Reboot&apply changes >
	verify > Repartition. Once dual boot process has been completed, copy altrom-format-all.zip 
	to the root of your SD Card then flash it in recovery. Once you do that you can flash Alt-ROMs
	in recovery. If you'd like to find Alt-ROMs look in my signature and click the link under "Projects"
	with the AltRoms in it. Enjoy!

NOT IMPLEMENTED YET:
ADB Sideload
	ADB Sideload flashes a ROM or Kernel in recovery without having to copy the flashable to your SD Card.
	This is useful to save time and is "supposed" to put less wear and tear on your flash memory. To do 
	sideload you must have TWRP installed. The Utility will boot up your device into recovery then YOU must
	selet "ADB Sideload" under the "Advanced" button in TWRP. Place your .zip file in the "SideLoad" folder 
	in the KFU directory. Then let KFU work its magic. Enjoy!
MORE TO COME...
	
                                88           88                                                       88  
                                ""           88                                                       88  
                                             88                                                       88  
,adPPYYba,  8b      db      d8  88   ,adPPYb,88  ,adPPYYba,  8b      db      d8  ,adPPYYba,   ,adPPYb,88  
""     `Y8  `8b    d88b    d8'  88  a8"    `Y88  ""     `Y8  `8b    d88b    d8'  ""     `Y8  a8"    `Y88  
,adPPPPP88   `8b  d8'`8b  d8'   88  8b       88  ,adPPPPP88   `8b  d8'`8b  d8'   ,adPPPPP88  8b       88  
88,    ,88    `8bd8'  `8bd8'    88  "8a,   ,d88  88,    ,88    `8bd8'  `8bd8'    88,    ,88  "8a,   ,d88  
`"8bbdP"Y8      YP      YP      88   `"8bbdP"Y8  `"8bbdP"Y8      YP      YP      `"8bbdP"Y8   `"8bbdP"Y8  
                                                                                                         